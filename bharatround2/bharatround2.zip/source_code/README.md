# SmartCampus AI — Source Code

## Bharat Academix CodeQuest 2026 — Round 2 Prototype

This folder contains the working prototype for **SmartCampus AI — Dropout Early
Warning System**.

---

## Files in this folder

| File | Description |
|---|---|
| `01_train_model.py` | Trains the Random Forest dropout-prediction model, generates risk scores, accuracy report, and analytics charts |
| `02_counselor_dashboard.html` | Interactive counselor dashboard — open directly in any browser. Includes a **Risk Monitor** tab and an **Intervention Tracker** tab |
| `03_intervention_tracker.py` | **Key differentiator.** Simulates and tracks counselor interventions, calculates an Intervention Success Rate, and shows which intervention types work best |
| `requirements.txt` | Python dependencies needed to run the model |

---

## What Makes This Different — The Intervention Feedback Loop

Most dropout-prediction prototypes stop at "here is a risk score." SmartCampus AI
goes one step further: it **closes the loop** by tracking what happens after a
counselor acts on a high-risk student.

- When a counselor logs an intervention (visible live in the dashboard's
  "Log Intervention" button), the system records the action type and schedules
  a follow-up risk check.
- After the follow-up window, the student's risk score is re-evaluated.
- This produces a real, calculable **Intervention Success Rate** — in our
  simulation, **~55-70%** depending on intervention type, with fee waivers
  showing the highest effectiveness.

**Honesty note:** these outcomes are simulated, since real semester-over-semester
student outcome data isn't available during a one-week hackathon. What this
demonstrates is the *system design* — a real deployment would log genuine
counselor actions and genuine follow-up outcomes, building real evidence over
each semester. This is explained on-screen in the dashboard itself (see the
"Intervention Tracker" tab, "Why This Matters" panel).

---

## How to Run the AI Model

### Step 1 — Install Python dependencies
```bash
pip install -r requirements.txt
```

### Step 2 — Run the model
```bash
python 01_train_model.py
```

### What happens when you run it
1. Generates a realistic synthetic dataset of 1,000 students (since real college
   ERP data is not available during the hackathon — see note below)
2. Trains a Random Forest Classifier on 7 behavioral and academic features
3. Prints model accuracy and a full classification report to the terminal
4. Saves `dropout_risk_report.csv` — risk score for every student
5. Saves `smartcampus_charts.png` — feature importance + risk distribution charts
6. Runs a live demo prediction for a sample at-risk student ("Priya")

### Note on the dataset
This prototype uses **synthetic data generated with realistic statistical
patterns** (matching real-world Indian college dropout indicators such as
attendance, marks, fee delays, and engagement). In a production deployment,
this would be replaced with a CSV export from the college's actual ERP system —
the model code does not need to change, only the data source.

---

## How to View the Counselor Dashboard

Simply open `02_counselor_dashboard.html` in any web browser (Chrome, Firefox,
Edge). No server or installation required.

### Dashboard features
- Live stats: High / Medium / Low risk student counts
- Searchable, filterable student risk table
- Click any student to see:
  - Their dropout risk score
  - Which factors are driving the risk (attendance, marks, fees, etc.)
  - The recommended counselor action

---

## Technology Stack

| Layer | Technology |
|---|---|
| AI / ML | Python, Scikit-learn (Random Forest Classifier) |
| Data Processing | Pandas, NumPy |
| Visualization | Matplotlib (model charts), Chart.js-style custom bars (dashboard) |
| Frontend | HTML, CSS, JavaScript (no framework — runs anywhere) |

---

## Model Performance

The Random Forest model is trained on 7 features:
- Attendance percentage
- Average marks
- Assignments submitted percentage
- Fee payment days overdue
- Library visits per month
- Number of failed subjects
- Counselor visits per semester

Output: a dropout risk probability score from 0–100%, with three risk bands:
- 🟢 Low Risk (0–39%)
- 🟡 Medium Risk (40–69%)
- 🔴 High Risk (70–100%)

See `documentation/Technical_Documentation.docx` for full architecture details.
