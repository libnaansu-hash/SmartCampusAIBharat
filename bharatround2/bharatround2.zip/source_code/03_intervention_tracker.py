# ============================================================
#  SmartCampus AI — Intervention Tracker & Outcome Loop
#  Bharat Academix CodeQuest 2026 — Round 2 Enhancement
#
#  WHAT THIS FILE DOES (in plain language):
#  ------------------------------------------
#  Most dropout-prediction projects stop at "here is a risk score."
#  This module answers the next, harder question: "Does acting on that
#  risk score actually help?"
#
#  It simulates what happens AFTER a counselor intervenes with a
#  high-risk student — does their risk go down over the following
#  weeks, or not? It then calculates a real "Intervention Success Rate"
#  metric, which becomes the strongest impact number in the whole
#  project (stronger than "29% of students drop out", because it
#  shows OUR system's effect, not just the background problem).
#
#  This simulation does NOT prove our specific predictions are accurate
#  for real students — we don't have real semester-over-semester data
#  yet. What it DOES prove is that the system is correctly designed to:
#    1. Log every intervention a counselor takes
#    2. Re-check the student's risk after a follow-up window
#    3. Calculate whether the intervention worked
#    4. Feed that result back so the system can be evaluated and
#       improved over time
#  This is the feedback loop a real production system needs — we are
#  showing the loop is CLOSEABLE, not claiming it is already closed
#  with real-world proof.
#
#  HOW TO RUN:
#    python 03_intervention_tracker.py
#    (run 01_train_model.py first if you haven't, so the model logic
#     is consistent — this script has its own self-contained model too)
#
#  OUTPUT:
#    - intervention_outcomes.csv   (every simulated intervention + result)
#    - intervention_success_chart.png (before/after risk comparison)
#    - Intervention Success Rate printed to terminal
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
import warnings
warnings.filterwarnings("ignore")

# ─────────────────────────────────────────
# WINDOWS FIX: force UTF-8 output so emoji/symbols (✓, 🔴, etc.)
# don't crash on Windows terminals that default to cp1252 encoding.
# This has no effect on Mac/Linux, where UTF-8 is already the default.
# ─────────────────────────────────────────
import sys
import io
if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

print("=" * 60)
print("  SmartCampus AI — Intervention Tracker & Outcome Loop")
print("  Bharat Academix CodeQuest 2026 — Round 2 Enhancement")
print("=" * 60)

np.random.seed(7)

# ─────────────────────────────────────────
# STEP 1: Load / simulate high-risk students who received intervention
# ─────────────────────────────────────────
print("\n[1/4] Identifying high-risk students who received a counselor intervention...")

N_INTERVENTIONS = 200  # number of high-risk students who got an intervention

intervention_types = [
    "Counseling session",
    "Fee waiver / installment plan",
    "Academic mentoring",
    "Parent meeting",
    "Peer support group referral",
]

records = []
for i in range(N_INTERVENTIONS):
    student_id = f"STU{2000+i}"

    # Initial (pre-intervention) risk score — these are all high-risk students
    initial_risk = np.random.normal(78, 10)
    initial_risk = max(60, min(99, initial_risk))

    # Which intervention did the counselor apply?
    action = np.random.choice(intervention_types, p=[0.35, 0.20, 0.20, 0.15, 0.10])

    # Simulate whether the intervention "worked"
    # Different intervention types have different (simulated) effectiveness —
    # this models realistic variation, not a guarantee of success
    effectiveness = {
        "Counseling session": 0.65,
        "Fee waiver / installment plan": 0.78,
        "Academic mentoring": 0.60,
        "Parent meeting": 0.55,
        "Peer support group referral": 0.45,
    }[action]

    worked = np.random.random() < effectiveness

    if worked:
        # Risk drops meaningfully over the follow-up window
        risk_change = -np.random.normal(28, 10)
        risk_change = max(-55, min(-5, risk_change))
    else:
        # Risk stays flat or even rises slightly
        risk_change = np.random.normal(3, 8)
        risk_change = max(-10, min(20, risk_change))

    follow_up_risk = max(5, min(99, initial_risk + risk_change))
    follow_up_days = np.random.choice([14, 21, 30, 45, 60])

    records.append({
        "student_id": student_id,
        "initial_risk_score": round(initial_risk, 1),
        "intervention_type": action,
        "follow_up_window_days": follow_up_days,
        "follow_up_risk_score": round(follow_up_risk, 1),
        "risk_change": round(follow_up_risk - initial_risk, 1),
        "outcome": "Improved" if (follow_up_risk - initial_risk) < -10 else
                   ("Worsened" if (follow_up_risk - initial_risk) > 5 else "No significant change"),
    })

df = pd.DataFrame(records)
print(f"   ✓ Tracked {len(df)} simulated interventions across 5 intervention types")

# ─────────────────────────────────────────
# STEP 2: Calculate Intervention Success Rate
# ─────────────────────────────────────────
print("\n[2/4] Calculating Intervention Success Rate...")

improved = (df["outcome"] == "Improved").sum()
no_change = (df["outcome"] == "No significant change").sum()
worsened = (df["outcome"] == "Worsened").sum()
success_rate = improved / len(df) * 100

print(f"   🟢 Improved:            {improved} students ({improved/len(df)*100:.1f}%)")
print(f"   🟡 No significant change: {no_change} students ({no_change/len(df)*100:.1f}%)")
print(f"   🔴 Worsened:            {worsened} students ({worsened/len(df)*100:.1f}%)")
print(f"\n   📊 OVERALL INTERVENTION SUCCESS RATE: {success_rate:.1f}%")

# ─────────────────────────────────────────
# STEP 3: Effectiveness by intervention type
# ─────────────────────────────────────────
print("\n[3/4] Breaking down success rate by intervention type...")

by_type = df.groupby("intervention_type").apply(
    lambda g: (g["outcome"] == "Improved").sum() / len(g) * 100
).sort_values(ascending=False)

for action, rate in by_type.items():
    count = (df["intervention_type"] == action).sum()
    print(f"   {action:.<38} {rate:.0f}% success  (n={count})")

best_intervention = by_type.idxmax()
print(f"\n   ⭐ Most effective intervention: {best_intervention} ({by_type.max():.0f}% success rate)")

# ─────────────────────────────────────────
# STEP 4: Save outcomes + visualization
# ─────────────────────────────────────────
print("\n[4/4] Saving outcomes report and chart...")

df.to_csv("intervention_outcomes.csv", index=False)
print("   ✓ Saved intervention_outcomes.csv")

NAVY = "#0A0F2E"
GOLD = "#F5C518"
GREEN = "#22C55E"
YELLOW = "#F5C518"
RED = "#E54B4B"

fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.patch.set_facecolor(NAVY)

# Chart 1 — Outcome breakdown donut
ax1 = axes[0]
ax1.set_facecolor(NAVY)
sizes = [improved, no_change, worsened]
labels = [f"Improved\n{improved} students", f"No Change\n{no_change} students", f"Worsened\n{worsened} students"]
colors = [GREEN, YELLOW, RED]
wedges, texts = ax1.pie(sizes, labels=labels, colors=colors, startangle=90,
                          wedgeprops=dict(width=0.45, edgecolor=NAVY, linewidth=2),
                          textprops=dict(color="white", fontsize=10))
ax1.set_title(f"Intervention Outcomes\n(n={len(df)} high-risk students)", color=GOLD, fontsize=12, fontweight="bold", pad=10)
ax1.text(0, 0, f"{success_rate:.0f}%\nSUCCESS", ha="center", va="center", color="white", fontsize=13, fontweight="bold")

# Chart 2 — Success rate by intervention type
ax2 = axes[1]
ax2.set_facecolor(NAVY)
y_pos = np.arange(len(by_type))
bars = ax2.barh(by_type.index, by_type.values, color=GOLD, height=0.55)
ax2.set_xlabel("Success Rate (%)", color="#AABBCC", fontsize=10)
ax2.set_title("Success Rate by Intervention Type", color=GOLD, fontsize=12, fontweight="bold", pad=10)
ax2.tick_params(colors="#AABBCC", labelsize=9)
ax2.set_xlim(0, 100)
for spine in ax2.spines.values():
    spine.set_color("#2A3560")
for bar, val in zip(bars, by_type.values):
    ax2.text(val + 2, bar.get_y() + bar.get_height()/2, f"{val:.0f}%", va="center", color="white", fontsize=9, fontweight="bold")

plt.tight_layout(pad=1.5)
plt.savefig("intervention_success_chart.png", dpi=150, bbox_inches="tight", facecolor=NAVY)
plt.close()
print("   ✓ Saved intervention_success_chart.png")

# ─────────────────────────────────────────
# Sample output for demo
# ─────────────────────────────────────────
print("\n" + "=" * 60)
print("  DEMO — Before / After Example")
print("=" * 60)
sample = df[df["outcome"] == "Improved"].iloc[0]
print(f"""
  Student: {sample['student_id']}
  Intervention applied: {sample['intervention_type']}
  Initial risk score: {sample['initial_risk_score']}%
  Risk score after {sample['follow_up_window_days']} days: {sample['follow_up_risk_score']}%
  Change: {sample['risk_change']:+.1f} points  →  Outcome: {sample['outcome']}
""")

print("=" * 60)
print("  NOTE: These outcomes are SIMULATED to demonstrate the")
print("  feedback-loop architecture. In production, this module")
print("  would log REAL counselor actions and REAL follow-up risk")
print("  scores from the live model, building a genuine evidence")
print("  base over each semester of real deployment.")
print("=" * 60)
