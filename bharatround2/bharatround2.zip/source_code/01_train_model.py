# ============================================================
#  SmartCampus AI — Student Dropout Early Warning System
#  Bharat Academix CodeQuest 2026
#
#  HOW TO RUN:
#    pip install scikit-learn pandas numpy matplotlib
#    python smartcampus_model.py
#
#  OUTPUT:
#    - Model accuracy printed in terminal
#    - dropout_risk_report.csv  (predictions for each student)
#    - feature_importance.png   (which factors matter most)
#    - risk_distribution.png    (how many students at each risk level)
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings("ignore")

# ─────────────────────────────────────────
# WINDOWS FIX: force UTF-8 output so emoji/symbols (✓, 🔴, etc.)
# don't crash on Windows terminals that default to cp1252 encoding.
# This has no effect on Mac/Linux, where UTF-8 is already the default.
# ─────────────────────────────────────────
import sys
import io
if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

# ─────────────────────────────────────────
# STEP 1: Generate Synthetic Student Data
# ─────────────────────────────────────────
# In a real college, this data comes from the ERP system.
# For the hackathon prototype, we generate realistic fake data.

print("=" * 55)
print("  SmartCampus AI — Dropout Early Warning System")
print("  Bharat Academix CodeQuest 2026")
print("=" * 55)
print("\n[1/5] Generating student dataset...")

np.random.seed(42)
N = 1000  # number of students

def generate_students(n):
    data = []
    for i in range(n):
        # Will this student drop out? (30% dropout rate — realistic for India)
        will_dropout = np.random.random() < 0.30

        # NOTE ON REALISM: Real student data is never perfectly separable —
        # some at-risk students still have okay attendance, some "safe"
        # students still struggle. We model that overlap deliberately by
        # widening the spread and adding independent random noise to each
        # feature, so the two groups overlap at the edges (just like real
        # life) instead of being two clean, easily-separated clusters.
        # This keeps the model's accuracy realistic (roughly 85-92%)
        # instead of a suspicious 100%, which would suggest the data was
        # artificially easy rather than the model being genuinely good.

        if will_dropout:
            # At-risk student profile (wider spread + noise = realistic overlap)
            attendance = np.random.normal(58, 20)
            avg_marks  = np.random.normal(50, 16)
            assignments_submitted = np.random.normal(45, 22)
            fee_days_overdue = np.random.normal(50, 32)
            library_visits_month = np.random.normal(2, 2)
            failed_subjects = np.random.choice([0, 1, 1, 2, 2, 3], 1)[0]
            counselor_visits = np.random.normal(0.8, 0.8)
        else:
            # Normal student profile (wider spread + noise = realistic overlap)
            attendance = np.random.normal(75, 16)
            avg_marks  = np.random.normal(64, 16)
            assignments_submitted = np.random.normal(78, 16)
            fee_days_overdue = np.random.normal(12, 16)
            library_visits_month = np.random.normal(5, 3)
            failed_subjects = np.random.choice([0, 0, 0, 1, 1, 2], 1)[0]
            counselor_visits = np.random.normal(1.8, 1.2)

        # Extra independent noise on top — simulates messy real-world data
        # (e.g. a struggling student who still attends class out of habit,
        # or a strong student going through a temporary rough patch)
        attendance += np.random.normal(0, 6)
        avg_marks += np.random.normal(0, 5)
        assignments_submitted += np.random.normal(0, 8)
        fee_days_overdue += np.random.normal(0, 8)

        # Clip values to realistic ranges
        data.append({
            "student_id": f"STU{1000+i}",
            "attendance_pct": max(0, min(100, attendance)),
            "avg_marks": max(0, min(100, avg_marks)),
            "assignments_submitted_pct": max(0, min(100, assignments_submitted)),
            "fee_days_overdue": max(0, min(180, fee_days_overdue)),
            "library_visits_per_month": max(0, min(20, library_visits_month)),
            "failed_subjects": min(6, failed_subjects),
            "counselor_visits_per_semester": max(0, min(10, counselor_visits)),
            "will_dropout": int(will_dropout),
        })
    return pd.DataFrame(data)

df = generate_students(N)
print(f"   ✓ Generated data for {N} students")
print(f"   ✓ Dropout students: {df['will_dropout'].sum()} ({df['will_dropout'].mean()*100:.1f}%)")
print(f"   ✓ Normal students:  {(~df['will_dropout'].astype(bool)).sum()}")

# ─────────────────────────────────────────
# STEP 2: Prepare Features
# ─────────────────────────────────────────
print("\n[2/5] Preparing features for the model...")

FEATURE_COLUMNS = [
    "attendance_pct",
    "avg_marks",
    "assignments_submitted_pct",
    "fee_days_overdue",
    "library_visits_per_month",
    "failed_subjects",
    "counselor_visits_per_semester",
]

X = df[FEATURE_COLUMNS]
y = df["will_dropout"]

# Split into training (80%) and testing (20%)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print(f"   ✓ Training samples: {len(X_train)}")
print(f"   ✓ Testing samples:  {len(X_test)}")

# ─────────────────────────────────────────
# STEP 3: Train the AI Model
# ─────────────────────────────────────────
print("\n[3/5] Training Random Forest model...")

model = RandomForestClassifier(
    n_estimators=100,    # 100 decision trees
    max_depth=8,         # Prevent overfitting
    random_state=42,
    class_weight="balanced"  # Handle imbalanced classes
)
model.fit(X_train, y_train)
print("   ✓ Model trained successfully!")

# Evaluate
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]  # Dropout probability 0-1

accuracy = accuracy_score(y_test, y_pred)
print(f"\n   📊 Model Accuracy: {accuracy*100:.1f}%")
print("\n   Detailed Report:")
print(classification_report(y_test, y_pred, target_names=["Not Dropout", "Dropout"]))

# ─────────────────────────────────────────
# STEP 4: Generate Risk Predictions
# ─────────────────────────────────────────
print("[4/5] Generating dropout risk scores for all students...")

all_probs = model.predict_proba(X)[:, 1]
df["dropout_risk_score"] = (all_probs * 100).round(1)

# Risk category
def risk_category(score):
    if score >= 70:
        return "🔴 HIGH RISK"
    elif score >= 40:
        return "🟡 MEDIUM RISK"
    else:
        return "🟢 LOW RISK"

df["risk_level"] = df["dropout_risk_score"].apply(risk_category)

# Identify primary reason for risk
def primary_reason(row):
    reasons = []
    if row["attendance_pct"] < 60:   reasons.append("Low attendance")
    if row["avg_marks"] < 50:        reasons.append("Low marks")
    if row["fee_days_overdue"] > 45: reasons.append("Fee overdue")
    if row["failed_subjects"] >= 2:  reasons.append("Failed subjects")
    if row["assignments_submitted_pct"] < 50: reasons.append("Missing assignments")
    return "; ".join(reasons) if reasons else "Monitoring"

df["primary_reason"] = df.apply(primary_reason, axis=1)

# Counselor action recommendation
def recommend_action(row):
    score = row["dropout_risk_score"]
    if score >= 70:
        return "URGENT: Schedule counseling + contact parents + check fee status"
    elif score >= 40:
        return "Schedule counseling session within 2 weeks"
    else:
        return "Regular monitoring — no immediate action needed"

df["recommended_action"] = df.apply(recommend_action, axis=1)

# Save report
report_cols = ["student_id", "dropout_risk_score", "risk_level",
               "attendance_pct", "avg_marks", "fee_days_overdue",
               "failed_subjects", "primary_reason", "recommended_action"]
report = df[report_cols].sort_values("dropout_risk_score", ascending=False)
report.to_csv("dropout_risk_report.csv", index=False)

high_risk = (df["dropout_risk_score"] >= 70).sum()
medium_risk = ((df["dropout_risk_score"] >= 40) & (df["dropout_risk_score"] < 70)).sum()
low_risk = (df["dropout_risk_score"] < 40).sum()

print(f"   ✓ Report saved to dropout_risk_report.csv")
print(f"\n   🔴 High Risk Students:   {high_risk}")
print(f"   🟡 Medium Risk Students: {medium_risk}")
print(f"   🟢 Low Risk Students:    {low_risk}")

# ─────────────────────────────────────────
# STEP 5: Visualizations
# ─────────────────────────────────────────
print("\n[5/5] Creating visualizations...")

# Chart 1: Feature Importance
fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.patch.set_facecolor("#0A0F2E")

importances = model.feature_importances_
feature_names = [
    "Attendance %",
    "Avg Marks",
    "Assignments %",
    "Fee Days Overdue",
    "Library Visits",
    "Failed Subjects",
    "Counselor Visits",
]
sorted_idx = np.argsort(importances)
colors = ["#F5C518" if i in sorted_idx[-3:] else "#3A4A7A" for i in range(len(importances))]

ax1 = axes[0]
ax1.set_facecolor("#0A0F2E")
bars = ax1.barh([feature_names[i] for i in sorted_idx],
                importances[sorted_idx],
                color=[colors[i] for i in sorted_idx])
ax1.set_xlabel("Importance Score", color="white", fontsize=11)
ax1.set_title("Which Factors Drive Dropout Risk?", color="white", fontsize=13, fontweight="bold")
ax1.tick_params(colors="white")
ax1.spines["bottom"].set_color("#3A4A7A")
ax1.spines["top"].set_visible(False)
ax1.spines["right"].set_visible(False)
ax1.spines["left"].set_color("#3A4A7A")

# Chart 2: Risk Distribution
ax2 = axes[1]
ax2.set_facecolor("#0A0F2E")
labels = ["Low Risk\n(< 40%)", "Medium Risk\n(40–70%)", "High Risk\n(> 70%)"]
sizes = [low_risk, medium_risk, high_risk]
bar_colors = ["#22C55E", "#F5C518", "#E54B4B"]
bars2 = ax2.bar(labels, sizes, color=bar_colors, width=0.5)
ax2.set_title("Student Risk Distribution", color="white", fontsize=13, fontweight="bold")
ax2.set_ylabel("Number of Students", color="white", fontsize=11)
ax2.tick_params(colors="white")
ax2.spines["bottom"].set_color("#3A4A7A")
ax2.spines["top"].set_visible(False)
ax2.spines["right"].set_visible(False)
ax2.spines["left"].set_color("#3A4A7A")
for bar, val in zip(bars2, sizes):
    ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
             str(val), ha="center", color="white", fontsize=12, fontweight="bold")

fig.suptitle("SmartCampus AI — Dropout Prediction Analytics", 
             color="white", fontsize=15, fontweight="bold", y=1.01)
plt.tight_layout()
plt.savefig("smartcampus_charts.png", dpi=150, bbox_inches="tight",
            facecolor="#0A0F2E")
plt.close()
print("   ✓ Charts saved to smartcampus_charts.png")

# ─────────────────────────────────────────
# BONUS: Predict a single new student
# ─────────────────────────────────────────
print("\n" + "=" * 55)
print("  DEMO — Predict risk for a new student")
print("=" * 55)

new_student = pd.DataFrame([{
    "attendance_pct": 48,
    "avg_marks": 42,
    "assignments_submitted_pct": 35,
    "fee_days_overdue": 70,
    "library_visits_per_month": 1,
    "failed_subjects": 2,
    "counselor_visits_per_semester": 0,
}])

risk_score = model.predict_proba(new_student)[0][1] * 100
print(f"\n  Student: Priya (2nd Year B.E.)")
print(f"  Attendance: 48%  |  Marks: 42  |  Fee Overdue: 70 days")
print(f"  Failed Subjects: 2  |  Assignments Submitted: 35%")
print(f"\n  ⚠  AI Dropout Risk Score: {risk_score:.1f}%")
print(f"  Status: {'🔴 HIGH RISK — Alert counselor immediately!' if risk_score >= 70 else '🟡 MEDIUM RISK'}")
print(f"\n  Recommended Action: Schedule urgent counseling +")
print(f"  contact parents + review fee waiver eligibility")

print("\n" + "=" * 55)
print("  All files generated successfully!")
print("  Files: dropout_risk_report.csv, smartcampus_charts.png")
print("=" * 55)
